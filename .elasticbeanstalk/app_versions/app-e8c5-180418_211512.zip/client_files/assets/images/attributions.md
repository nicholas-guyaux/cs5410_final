# attributions

https://opengameart.org/content/navy-cruiser

https://opengameart.org/content/a-few-little-assets-for-a-1942-clone
