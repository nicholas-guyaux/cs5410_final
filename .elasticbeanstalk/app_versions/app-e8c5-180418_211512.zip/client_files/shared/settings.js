(function (exports) {
  Object.assign(exports,{
    waterUnitScale: 0.75,
  });
})(typeof exports === 'undefined' ? this['settings'] = {} : exports);
