modue.exports = function Shield (x, y) {
  const points = [
    [0,0],
    [1,0],
    [1,1],
    [0,1],
  ].map(p => {
    
  });
  
  var that = Geometry.circle({
    x:,
    y:,
  });
}
