module.exports = {
  numPlayersRequired: 2,
}
